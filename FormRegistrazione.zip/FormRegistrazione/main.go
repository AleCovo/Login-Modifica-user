package main

import (
	"github.com/gin-gonic/gin"
	"github.com/whitone/ifc"
	"gorm.io/gorm"
	"log"
	"net/http"
)
type  User struct{
	gorm.Model
	Cognome string `form:"cognome"`
	Nome string `form:"nome"`
	DataNascita string `form:"dataNascita"`
	ComuneNascita string `form:"comuneNascita"`
	ProvinciaNascita string `form:"provinciaNascita"`
	Telefono string `form:"telefono"`
	Email string `form:"email"`
	IndirizzoResidenza string `form:"indirizzoResidenza"`
	ComuneResidenza string `form:"comuneResidenza"`
	ProvinciaResidenza string `form:"provinciaResidenza"`
	Sesso string `form:"sesso"`
	CodiceFiscale string `form:"codiceFiscale"`
}
func addRecord(n1 User){
	db, err := GetGormDBConnection()
	if err != nil{
		panic(err)
	}
	n1.CodiceFiscale,err=ifc.Encode(n1.Cognome,n1.Nome,n1.Sesso[0],n1.DataNascita,n1.ComuneNascita)
	if err != nil {log.Fatal(err)}
	db.Create(&n1)
}
func delRecord(id int){
	db, err := GetGormDBConnection()
	if err != nil{
		panic(err)
	}
	db.Delete(&User{}, id)
}
func updRecord(id int, n1 User){
	db, err := GetGormDBConnection()
	_ = err
	if len(n1.Cognome)>1 {
		db.Model(&n1).Where(id).Update("cognome",n1.Cognome)
	}
	if len(n1.Nome)>1 {
		db.Model(&n1).Where(id).Update("nome",n1.Nome)
	}
	if len(n1.DataNascita)==10 {
		db.Model(&n1).Where(id).Update("data_nascita",n1.DataNascita)
	}
	if len(n1.ComuneNascita)>1 {
		db.Model(&n1).Where(id).Update("comune_nascita",n1.ComuneNascita)
	}
	if len(n1.ProvinciaNascita)>1 {
		db.Model(&n1).Where(id).Update("provincia_nascita",n1.ProvinciaNascita)
	}
	if len(n1.Telefono)==10 {
		db.Model(&n1).Where(id).Update("telefono",n1.Telefono)
	}
	if len(n1.Email)>7 {
		db.Model(&n1).Where(id).Update("email",n1.Email)
	}
	if len(n1.IndirizzoResidenza)>5 {
		db.Model(&n1).Where(id).Update("indirizzo_residenza",n1.IndirizzoResidenza)
	}
	if len(n1.ComuneResidenza)>1 {
		db.Model(&n1).Where(id).Update("comune_residenza",n1.ComuneResidenza)
	}
	if len(n1.ProvinciaResidenza)>1 {
		db.Model(&n1).Where(id).Update("provincia_residenza",n1.ProvinciaResidenza)
	}
	db.Model(&n1).Where(id).Update("sesso",n1.Sesso)
	if len(n1.Cognome) > 1 || len(n1.Nome) > 1 || len(n1.DataNascita) == 10 || len(n1.ComuneNascita) > 1 || len(n1.Sesso) > 0 {
		db.Find(&n1, id)
		n1.CodiceFiscale,err=ifc.Encode(n1.Cognome,n1.Nome,n1.Sesso[0],n1.DataNascita,n1.ComuneNascita)
		db.Model(&n1).Where(id).Update("codice_fiscale",n1.CodiceFiscale)
		if err != nil {log.Fatal(err)}
	}
}
func init(){
	InitializeDBConnection()
	db, err:=GetGormDBConnection()
	if err != nil{
		panic(err)
	}
	db.AutoMigrate(&User{})
}
func main(){
	router := gin.Default()
	router.POST("/registerForm", func(c *gin.Context) {
		var n1 User
		if err := c.ShouldBind(&n1); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		}
		addRecord(n1)
	})
	router.POST("/updateForm", func(c *gin.Context) {
		var n1 User
		if err := c.ShouldBind(&n1); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		}
		updRecord(1, n1)

	})
	router.Run(":8080")
}